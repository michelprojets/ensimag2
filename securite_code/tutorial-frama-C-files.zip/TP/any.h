/* returns an integer from standard input */
extern int any();
