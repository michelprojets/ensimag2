README:
-------

TODO in this order:
 - mult.c
 - arith1.c
 - div0.c
 - div1.c
 - linear_search.c
 - min_sort.c
